<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            // UserSeeder::class,
            // PermissionSeeder::class,
            // UsersPermissionSeeder::class,
            // CurrencySeeder::class,
            SystemSeeder::class,
            ContentAdvisorySeeder::class,


        ]);
    }
}
