<?php


namespace App\Http\Controllers\Admin\Videos;


use App\User;
use App\Image;
use App\Video;
use App\VideoEpisode;
use App\Activity;
use App\Category;
use App\Section;

use App\Http\Helper;
use App\SystemSetting;
use App\RelatedVideo;
use App\Genre;
use App\ContentAdvisory;
use App\Jobs\SendPushCampaign;
use App\PushCampaign;
use Illuminate\Http\Request;

use Illuminate\Validation\Rule;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Str;


class VideosController extends Controller
{

    protected $settings;

    public function __construct()
    {
        $this->settings =  SystemSetting::first();
    }

    /**
     * Display a listing of the resource.
     *
     * return \Illuminate\Http\Response
     */
    public function index()
    {
        $videos = Video::withCount('episodes')->orderBy('created_at', 'desc')->paginate(30);
        $system_settings = SystemSetting::first();
        return view('admin.videos.index', compact('system_settings', 'videos'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * return \Illuminate\Http\Response
     */
    public function create()
    {
        User::canTakeAction(2);
        $categories = Category::parents()->get();
        $genres  = Genre::latest()->get();
        $contentAdvisories = ContentAdvisory::ordered()->get();
        $sections = Section::latest()->get();
        $filmers = (new User())->filmers()->latest()->get();
        $casts = (new User())->castings()->latest()->get();
        $excludes = Video::excludes();
        return view('admin.videos.create', compact('excludes', 'genres', 'sections', 'filmers', 'casts', 'categories', 'contentAdvisories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * param  \Illuminate\Http\Request  $request
     * return \Illuminate\Http\Response
     */
    public function store(Request $request, Video $video)
    {
        abort_unless(User::userHasPermission(2), 403);

        //
        $this->validate($request, [
            'content_type' => 'nullable|in:movie,series',
            'content_advisory_ids' => 'nullable|array',
            'content_advisory_ids.*' => 'required|integer|distinct|exists:content_advisories,id',
            'buy_price'  =>  'required',
            'rent_price' =>  'required',
            'buy_price_usd'  =>  'nullable|numeric',
            'rent_price_usd' =>  'nullable|numeric',
            "cast_id"    =>  "required|array",
            "genre_id"  =>  "required|array",
            "filmer_id"  =>  "required|array",
            "section_id" =>  "required|array|min:1",
            "section_id.*" => "integer|exists:sections,id",
            "excludes"   =>  "nullable|array",
            "excludes.*" =>  [Rule::in(array_keys(Video::excludes()))],
            'poster'     =>  'required',
            'tn_poster'  =>  'required',
            'track_file' => $this->subtitleFileRules(),
            'title' => [
                'required',
                Rule::unique('videos')->where(function ($query) use ($request) {
                    $query->where('deleted_at', '=', null);
                })
            ],
        ]);

        $contentType = $request->input('content_type', 'movie');
        $this->validateVideoContent($request, $contentType);

        if ($request->hasFile('track_file')) {
            $video->track_file = $this->storeSubtitleFile($request->file('track_file'));
        }

        $video->title  = $request->title;
        $video->content_type = $contentType;
        $video->slug = str_slug($request->title . '-' . $request->description);
        $video->preview_link = Video::normalizePreviewLink($request->preview_link);
        $video->duration = $request->duration;
        $video->poster  = $request->poster;
        $video->tn_poster = $request->tn_poster;
        $video->duration = $request->duration;
        $video->buy_price = $request->buy_price;
        $video->rent_price = $request->rent_price;
        $video->buy_price_usd = $request->buy_price_usd;
        $video->rent_price_usd = $request->rent_price_usd;
        $video->film_rating = $request->film_rating;
        $video->description = $request->description;
        $video->resolution = $request->resolution;
        $video->release_date = Helper::getFormatedDate($request->release_date); //Format data
        $video->link = $request->link;
        $video->iframe = $request->iframe;
        $video->blocked_continents = array_values($request->input('excludes', []));
        $video->featured = $request->featured_video ? 1 : 0;
        $video->access_type = $request->access_type;
        $video->save();
        $video->contentAdvisories()->sync($request->input('content_advisory_ids', []));
        $this->syncEpisodes($video, $request);

        if (!empty($request->category_id)) {
            $video->categories()->sync($request->category_id);
            $categories = Category::find($request->category_id);
            foreach ($categories as $category) {
                $category->sections()->sync($request->section_id);
            }
        }

        if (!empty($request->cast_id)) {
            $video->casts()->sync($request->cast_id);
        }

        // A homepage section is required. Browse only renders videos attached to sections.
        $video->sections()->sync($request->section_id);

        if (!empty($request->genre_id)) {
            $video->genres()->sync($request->genre_id);
        }

        if (!empty($request->filmer_id)) {
            $video->filmers()->sync($request->filmer_id);
        }

        if (!empty($request->related_videos)) {
            foreach ($request->related_videos as $key => $video_id) {
                $video->related_videos()->create([
                    'related_id' =>  $video_id,
                    'sort_order' => $request->sort_order[$key],
                ]);
            }
        }

        (new Activity)->Log("Created a new video {$request->title}");
        return redirect()->route('videos.index')->with('success', 'Video  added');
    }

    public function destroyRelatedVideo(Request $request, $id)
    {
        RelatedVideo::destroy($id);
        return response('done', 200);
    }

    public function toggleActive(Request $request, Video $video)
    {
        User::canTakeAction(3);

        $video->is_active = ! (bool) $video->is_active;
        $video->save();

        (new Activity)->Log(($video->is_active ? 'Activated' : 'Deactivated') . " video {$video->title}");

        return response()->json([
            'success' => true,
            'is_active' => (bool) $video->is_active,
            'label' => $video->is_active ? 'Active' : 'Inactive',
        ]);
    }

    public function sendPushNotification(Request $request)
    {
        User::canTakeAction(3);

        $this->validate($request, [
            'selected' => 'required|array|min:1',
            'selected.*' => 'integer|distinct|exists:videos,id',
            'messages' => 'nullable|array',
            'messages.*' => 'array',
            'messages.*.title' => 'nullable|string|max:150',
            'messages.*.body' => 'nullable|string|max:500',
        ], [
            'selected.required' => 'Select at least one video to notify viewers about.',
        ]);

        $videos = Video::whereIn('id', $request->input('selected'))->get();
        $campaigns = \DB::transaction(function () use ($request, $videos) {
            return $videos->map(function ($video) use ($request) {
                $custom = $request->input('messages.'.$video->id, []);
                $title = trim((string) ($custom['title'] ?? ''));
                $body = trim((string) ($custom['body'] ?? ''));
                if ($title === '') $title = Str::limit('New on Nollyflix: '.$video->title, 150, '');
                if ($body === '') $body = Str::limit(trim(strip_tags((string) $video->description)), 120);
                if ($body === '') $body = 'Open Nollyflix to watch now.';

                $campaign = PushCampaign::create([
                    'created_by' => optional($request->user())->id,
                    'title' => $title,
                    'body' => $body,
                    'data' => [
                        'type' => 'video_release',
                        'url' => 'nollyflix://video/'.$video->id,
                        'video_id' => (string) $video->id,
                    ],
                    'status' => 'queued',
                ]);
                $campaign->videos()->sync([$video->id]);
                return $campaign;
            });
        });

        foreach ($campaigns as $campaign) {
            SendPushCampaign::dispatch($campaign->id);
        }

        (new Activity)->Log('Queued a push notification for '.$videos->count().' video(s)');

        return redirect()->route('videos.index')->with('success', $campaigns->count().' movie notification(s) queued for delivery.');
    }

    public function search(Request $request)
    {
        $filtered_array = $request->only(['q', 'field']);
        if (empty($filtered_array['q'])) {
            return redirect('/errors');
        }
        if ($request->has('q')) {
            $filtered_array = array_filter($filtered_array);
            $query = Video::select('videos.*')->with('categories')->join('category_video', function ($join) {
                    $join->on('category_video.video_id', '=', 'videos.id');
                })->join('categories', function ($join) {
                    $join->on('category_video.category_id', '=', 'categories.id');
                })
                ->where(function ($query) use ($filtered_array) {
                    $query->where('categories.name', 'like', '%' . $filtered_array['q'] . '%')
                        ->orWhere('videos.title', 'like', '%' . $filtered_array['q'] . '%');
                });
        }

        $videos = $query->withCount('episodes')->groupBy('videos.id')->get();
        $system_settings = SystemSetting::first();
        return view('admin.videos.index', compact('system_settings', 'videos'));
    }

    /**
     * Display the specified resource.
     *
     * param  \App\Video  $video
     * return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $product = Video::find($id);
        //$product_images = $product->product_images->slice(1);
        return view('admin.videos.show', compact('product'));
    }


    public function getRelatedVideos(Request $request)
    {
        if ($request->filled('title')) {
            $videos = Video::where('title', 'like', '%' . $request->title . '%')
                ->take(10)
                ->get();
            return view('admin.videos.related_videos', compact('videos'));
        }
        return [];
    }



    /**
     * Show the form for editing the specified resource.
     *
     * param  \App\Product  $product
     * return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        User::canTakeAction(3);
        $categories = Category::parents()->get();
        $genres = Genre::latest()->get();
        $contentAdvisories = ContentAdvisory::ordered()->get();
        $sections = Section::latest()->get();
        $filmers = (new User())->filmers()->latest()->get();
        $casts = (new User())->castings()->latest()->get();
        $video = Video::with('episodes', 'contentAdvisories')->findOrFail($id);
        $excludes = Video::excludes();

        return view('admin.videos.edit', compact('excludes', 'genres', 'filmers', 'sections', 'casts', 'categories', 'video', 'contentAdvisories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * param  \Illuminate\Http\Request  $request
     * param  \App\Product  $product
     * return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        abort_unless(User::userHasPermission(3), 403);
        //
        $this->validate($request, [
            'content_type' => 'nullable|in:movie,series',
            'content_advisory_ids' => 'nullable|array',
            'content_advisory_ids.*' => 'required|integer|distinct|exists:content_advisories,id',
            'buy_price'  =>  'required',
            'rent_price' =>  'required',
            'buy_price_usd'  =>  'nullable|numeric',
            'rent_price_usd' =>  'nullable|numeric',
            "cast_id"    =>  "required|array",
            "genre_id"    =>  "required|array",
            "filmer_id"  =>  "required|array",
            "section_id" =>  "required|array|min:1",
            "section_id.*" => "integer|exists:sections,id",
            "excludes"   =>  "nullable|array",
            "excludes.*" =>  [Rule::in(array_keys(Video::excludes()))],
            'poster'     =>  'required',
            'tn_poster'  =>  'required',
            'track_file' => $this->subtitleFileRules(),
            'title' =>  'required|unique:videos,title,' . $id,
        ]);

        $contentType = $request->input('content_type', 'movie');
        $this->validateVideoContent($request, $contentType);

        $video = Video::find($id);

        if ($request->hasFile('track_file')) {
            $video->track_file = $this->storeSubtitleFile($request->file('track_file'));
        }


        $video->title = $request->title;
        $video->content_type = $contentType;
        $video->slug = str_slug($request->title . '-' . $request->description);
        $video->preview_link = Video::normalizePreviewLink($request->preview_link);
        $video->duration = $request->duration;
        $video->poster = $request->poster;
        $video->tn_poster = $request->tn_poster;
        $video->duration = $request->duration;
        $video->buy_price = $request->buy_price;
        $video->rent_price = $request->rent_price;
        $video->buy_price_usd = $request->buy_price_usd;
        $video->rent_price_usd = $request->rent_price_usd;
        $video->film_rating = $request->film_rating;
        $video->description = $request->description;
        $video->resolution = $request->resolution;
        $video->blocked_continents = array_values($request->input('excludes', []));
        $video->release_date = $request->filled('release_date') ?  Helper::getFormatedDate($request->release_date) : $video->release_date; //Format data
        $video->link = $request->link;
        $video->iframe = $request->iframe;
        $video->featured = $request->featured_video ? 1 : 0;
        $video->access_type = $request->access_type;
        $video->save();
        // An unchecked form clears all advisories; older clients that omit this
        // field entirely must not silently erase an existing classification.
        if ($request->has('content_advisories_present') || $request->has('content_advisory_ids')) {
            $video->contentAdvisories()->sync($request->input('content_advisory_ids', []));
        }
        $this->syncEpisodes($video, $request);

        if (!empty($request->category_id)) {
            $video->categories()->sync($request->category_id);
            $categories = Category::find($request->category_id);
            foreach ($categories as $category) {
                $category->sections()->sync($request->section_id);
            }
        }

        if (!empty($request->cast_id)) {
            $video->casts()->sync($request->cast_id);
        }

        // A homepage section is required. Browse only renders videos attached to sections.
        $video->sections()->sync($request->section_id);

        if (!empty($request->genre_id)) {
            $video->genres()->sync($request->genre_id);
        }

        if (!empty($request->filmer_id)) {
            $video->filmers()->sync($request->filmer_id);
        }


        if (!empty($request->related_videos)) {
            foreach ($request->related_videos as $key => $video_id) {
                $sort_order = isset($request->sort_order[$key]) ? $request->sort_order[$key] : null;

                if (! $video_id) {
                    continue;
                }

                $video->related_videos()->updateOrCreate(
                    [
                        'id' =>  $key
                    ],
                    [
                        'related_id' =>  $video_id,
                        'sort_order' =>  $sort_order,
                    ]
                );
            }
        }


        (new Activity)->Log("Edited a new video {$request->title}");
        return redirect()->route('videos.index')->with('success', 'Video  Updated');
    }



    protected function validateVideoContent(Request $request, $contentType)
    {
        if ($contentType === 'series') {
            $this->validate($request, [
                'episodes' => 'required|array',
                'episodes.*.link' => 'required',
                'episodes.*.season_number' => 'nullable|integer|min:1',
                'episodes.*.episode_number' => 'nullable|integer|min:1',
                'episodes.*.track_file' => $this->subtitleFileRules(),
            ]);
            return;
        }

        $this->validate($request, [
            'link' => 'required',
        ]);
    }

    protected function syncEpisodes(Video $video, Request $request)
    {
        if ($video->content_type !== 'series') {
            $video->episodes()->delete();
            return;
        }

        $episodeIds = [];

        foreach ($request->input('episodes', []) as $index => $episodeData) {
            if (empty($episodeData['link'])) {
                continue;
            }

            $episode = null;
            if (!empty($episodeData['id'])) {
                $episode = $video->episodes()->where('id', $episodeData['id'])->first();
            }

            if (!$episode) {
                $episode = new VideoEpisode;
            }

            $episode->season_number = !empty($episodeData['season_number']) ? (int) $episodeData['season_number'] : 1;
            $episode->episode_number = !empty($episodeData['episode_number']) ? (int) $episodeData['episode_number'] : ($index + 1);
            $episode->title = isset($episodeData['title']) ? $episodeData['title'] : null;
            $episode->duration = isset($episodeData['duration']) ? $episodeData['duration'] : null;
            $episode->link = $episodeData['link'];
            $episode->preview_link = isset($episodeData['preview_link'])
                ? Video::normalizePreviewLink($episodeData['preview_link'])
                : null;
            $episode->iframe = isset($episodeData['iframe']) ? $episodeData['iframe'] : null;

            $episodeTrackFile = $request->file('episodes.' . $index . '.track_file');
            if ($episodeTrackFile) {
                $episode->track_file = $this->storeSubtitleFile($episodeTrackFile, 'videos/subtitles/episodes');
            }

            $episode->sort_order = isset($episodeData['sort_order']) ? (int) $episodeData['sort_order'] : $index;

            $video->episodes()->save($episode);
            $episodeIds[] = $episode->id;
        }

        if (!empty($episodeIds)) {
            $video->episodes()->whereNotIn('id', $episodeIds)->delete();
        }
    }

    protected function subtitleFileRules()
    {
        return [
            'nullable',
            'file',
            'max:5120',
            function ($attribute, $value, $fail) {
                $extension = strtolower($value->getClientOriginalExtension());

                if (!in_array($extension, ['vtt', 'srt'], true)) {
                    $fail('Subtitle files must be WebVTT (.vtt) or SubRip (.srt) files.');
                }
            },
        ];
    }

    protected function storeSubtitleFile($file, $directory = 'videos/subtitles')
    {
        $extension = strtolower($file->getClientOriginalExtension());
        $contents = File::get($file->getRealPath());
        $contents = preg_replace('/^\xEF\xBB\xBF/', '', $contents);
        $contents = str_replace(["\r\n", "\r"], "\n", $contents);

        if ($extension === 'srt') {
            $contents = preg_replace(
                '/(\d{2}:\d{2}:\d{2}),(\d{3})/',
                '$1.$2',
                $contents
            );
            $contents = "WEBVTT\n\n" . trim($contents) . "\n";
        } elseif (stripos(ltrim($contents), 'WEBVTT') !== 0) {
            $contents = "WEBVTT\n\n" . trim($contents) . "\n";
        }

        $directory = trim($directory, '/');
        $path = $directory . '/' . Str::random(40) . '.vtt';
        Storage::disk('local')->put($path, $contents);

        return asset($path);
    }

    /**
     * Remove the specified resource from storage.
     *
     * param  \App\Product  $product
     * return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        User::canTakeAction(5);
        $rules = array(
            '_token' => 'required'
        );
        $validator = \Validator::make($request->all(), $rules);
        if (empty($request->selected)) {
            $validator->getMessageBag()->add('Selected', 'Nothing to Delete');
            return \Redirect::back()->withErrors($validator)->withInput();
        }
        $count = count($request->selected);
        $delete = Video::destroy($request->selected);
        (new Activity)->Log("Deleted  {$count} Videos");
        return redirect()->back()->with('success', "Deleted  {$count} Videos");
    }
}
