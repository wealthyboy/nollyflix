<?php

namespace App\Http\Controllers\Api\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Auth\RegisterRequest;
use App\Http\Resources\PrivateUserResource;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class RegisterController extends Controller
{
    public function action(RegisterRequest $request)
    {
        $user   = User::create([
            'name'  =>  $request->first_name,
            'last_name' =>  $request->last_name,
            'email'     =>  $request->email,
            'phone_number' => $request->phone_number,
            'type' => 'subscriber',
            'password'  =>  bcrypt($request->password)
        ]);

        Log::info($user);

        $token = \JWTAuth::fromUser($user);
        $user->update(['api_token' => $token]);

        return (new PrivateUserResource($user))->additional([
            'meta' => ['token' => $token],
        ]);
    }
}
