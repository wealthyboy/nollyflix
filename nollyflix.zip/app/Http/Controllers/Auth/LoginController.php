<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Providers\RouteServiceProvider;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    /**
     * Where to redirect users after login.
     *
     * @var string
     */
    protected $redirectTo = RouteServiceProvider::HOME;

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest',['except' => [
                'logout',
                "me"
            ]
        ]);
    }


    protected function authenticated(Request $request,$user)
    {
        if ($user->type === 'casts') {
            $request->session()->forget('url.intended');
            if ($request->ajax() || $request->wantsJson()) {
                return response()->json(['loggedIn' => true, 'user' => $user,
                    'redirect' => route('actors.dashboard')]);
            }
            return redirect()->route('actors.dashboard');
        }

        if ( $request->ajax() ) { 
		    return response()->json([
				'loggedIn'=>true,
				'user' => auth()->user()
			],200);
		}
    }

    public function me(){
        if (auth()->check()){
            return  response()->json([
                'loggedIn' => true,
                'user' =>  auth()->user()
            ],200);
        }

        return response()->json(null,401);
    }
}
