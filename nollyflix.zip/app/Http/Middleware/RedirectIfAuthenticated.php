<?php

namespace App\Http\Middleware;

use App\Providers\RouteServiceProvider;
use Closure;
use Illuminate\Support\Facades\Auth;

class RedirectIfAuthenticated
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {
        if (Auth::guard($guard)->check()) {
            return in_array(Auth::guard($guard)->user()->type, ['casts', 'filmakers'], true)
                ? redirect()->route(Auth::guard($guard)->user()->must_change_password ? 'contributor.password.edit' : 'actors.dashboard')
                : redirect(RouteServiceProvider::HOME);
        }

        return $next($request);
    }
}
